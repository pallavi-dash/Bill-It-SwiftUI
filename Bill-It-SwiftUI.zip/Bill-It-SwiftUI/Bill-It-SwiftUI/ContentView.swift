//
//  ContentView.swift
//  Bill-It-SwiftUI
//
//  Created by Pallavi Dash on 25/09/19.
//  Copyright © 2019 Pallavi Dash. All rights reserved.
//

import SwiftUI

struct BillType: Identifiable {
    var id = UUID()
    var billType: String
}

let billType = [
    BillType(billType: "Food"),
    BillType(billType: "Travel")
    
]

struct BillDetails: Identifiable {
    var id = UUID()
    var billDetails: String
    var type: String
}

//Variable to store the text of the processed image
var resultingText = ""
var billDetailsArray = [[String:String]]()
var indicatorState = false
var billDetails = [BillDetails(billDetails: "", type: "Food")]

struct ContentView: View {
    var body: some View {
        NavigationView {
            BillScanView()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

//
//  BillDetailsView.swift
//  Bill-It-SwiftUI
//
//  Created by Pallavi Dash on 25/09/19.
//  Copyright © 2019 Pallavi Dash. All rights reserved.
//

import Foundation
import SwiftUI

struct BillDetailsView: View {
    let billType: String = selectedType
    let billingDetail: [BillDetails] = billDetails.filter{$0.type == selectedType}
    var body: some View {
        VStack {
            List(billingDetail) { bill in
                BillDetailsCell(bills: bill)
            }
        }
    .navigationBarTitle("Bill Details")
    }
}

struct BillDetailsCell: View {
    let bills : BillDetails
    var body: some View {
            VStack(alignment: .leading) {
                Text(bills.billDetails)
        }
    }
}

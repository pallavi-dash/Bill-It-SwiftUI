//
//  BillScanView.swift
//  Bill-It-SwiftUI
//
//  Created by Pallavi Dash on 25/09/19.
//  Copyright © 2019 Pallavi Dash. All rights reserved.
//

import Foundation
import SwiftUI
import Vision
import VisionKit

struct BillScanView: View {
    
    @State private var showImagePicker: Bool = false
    @State private var image: Image? = nil
    
    var billCategory = ["Food", "Travel"]
    
    @State private var showSheet = false
    @State private var selectedColor = 0
    
    var body: some View {
        VStack {
            image?.resizable().scaledToFit()
            if image == nil {
                VStack {
                    ZStack {
                        Image("scan")
                        Image("barcode")
                    }
                    Text("Scan Bill")
                        .foregroundColor(.blue)
                    
                    HStack {
                        Button(action: {
                            self.showImagePicker = true}) {
                                Image(systemName: "photo.fill").renderingMode(Image.TemplateRenderingMode?.init(Image.TemplateRenderingMode.original))
                        }
                        .padding()
                        .padding(.leading,CGFloat(12))
                        .padding(.top,CGFloat(30))
                        
                        Button(action: {
                            self.showImagePicker = true}) {
                                Image(systemName: "camera").renderingMode(Image.TemplateRenderingMode?.init(Image.TemplateRenderingMode.original))
                        }
                        .padding()
                        .padding(.leading,CGFloat(12))
                        .padding(.top,CGFloat(30))
                    }
                }
            } else {
                VStack {
                    Text("Select Category")
                        .padding()
                        .padding(.leading,CGFloat(12))
                        .padding(.top,CGFloat(30))
                    Picker(selection: self.$selectedColor, label: Text(""))
                    {
                        ForEach(0 ..< self.billCategory.count) {
                            Text(self.billCategory[$0])
                        }
                    }
                    .fixedSize()
                    .padding()
                    .padding(.trailing,CGFloat(20))
                    .padding(.bottom,CGFloat(100))
                }
                .navigationBarItems(trailing: NavigationLink(destination: BillCategoryView(), label: {
                    Text("Save")
                }))
            }
        }
        .sheet(isPresented: self.$showImagePicker) { PhotoCaptureView(showImagePicker: self.$showImagePicker, image: self.$image)
        }
    }
}

